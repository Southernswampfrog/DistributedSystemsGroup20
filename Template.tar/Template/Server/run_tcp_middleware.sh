java -cp java-json.jar:../Server Server.TCP.TCPMiddleware $1 $2 $3 $4 $5 $6
