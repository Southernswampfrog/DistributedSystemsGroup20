java -cp java-json.jar:../Server Server.TCP.TCPResourceManager $1 $2
