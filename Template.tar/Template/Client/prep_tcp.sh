rm ../Server/RMIInterface.jar
cd ../Server
make
cd ../Client
make
