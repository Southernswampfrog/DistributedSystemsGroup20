
java -cp java-json.jar:../Client Client.TCPTestClient $1 $2