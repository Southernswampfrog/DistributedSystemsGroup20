
java -cp java-json.jar:../Client Client.TCPClient $1 $2